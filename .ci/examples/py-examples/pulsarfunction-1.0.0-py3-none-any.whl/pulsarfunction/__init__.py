"""
Pulsar Function helper package.

This wheel previously used pkg_resources.declare_namespace(), which
requires pkg_resources (removed from setuptools>=82). The package is
not a namespace package, so we keep __init__ side-effect free.
"""
